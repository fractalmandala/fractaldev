# Fractal style guard integration

The pack uses one closed registry across agent instructions, MCP discovery,
recipes, editor data, and deterministic validation.

## Surfaces

- `data/registry.json` is the canonical read map.
- `config/policy.json` defines the closed-world enforcement policy.
- `data/recipes.json` contains only registry-validated compositions.
- `skills/fractal-style-guard/SKILL.md` defines mandatory agent behavior.
- `mcp/fractal_style_mcp.rb` exposes read-only discovery and validation tools.
- `scripts/fractal-style-check` is the enforceable file/CI gate.

## MCP tools

The local stdio server exposes five tools:

- `fractal_style_get_rules`
- `fractal_style_search_classes`
- `fractal_style_get_class`
- `fractal_style_find_recipes`
- `fractal_style_validate_markup`

All tools are read-only, idempotent, and closed-world. There is deliberately no
tool for creating classes, compiling custom Sass, or mutating the registry.

## Enforce in a repository

Run the file gate over every changed UI source before accepting agent output:

```sh
ruby /path/to/fractal-style-guard/scripts/fractal-style-check src/**/*.svelte
```

Exit code `0` means every discovered class is canonical and no forbidden style
surface was found. Exit code `1` means the output must be corrected or reported
as a design-system coverage gap. Exit code `2` means the command was misused.

The validator is intentionally conservative. Dynamic class expressions require
a separate call with the complete set of possible emitted class names; never
approve an expression whose output cannot be enumerated.
