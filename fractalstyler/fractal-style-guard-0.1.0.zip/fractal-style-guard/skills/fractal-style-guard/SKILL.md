---
name: fractal-style-guard
description: Build, modify, or audit interfaces that must use only the closed Fractal styling vocabulary. Use whenever authoring HTML, Svelte, CSS, Sass, JavaScript, or TypeScript UI where new classes, style blocks, inline styles, custom properties, or CSS definitions are forbidden.
---

# Fractal style guard

Use the Fractal registry as a closed world. Never invent a class or styling
definition, even when the requested design is not fully covered.

## Mandatory workflow

1. Call `fractal_style_get_rules` before styling work.
2. Search recipes with `fractal_style_find_recipes` for the requested intent.
3. Search or inspect classes with `fractal_style_search_classes` and
   `fractal_style_get_class`. Never rely on class-name intuition.
4. Compose markup only from verified registry names. Preserve native semantic
   elements and accessibility attributes; these are not styling escapes.
5. Call `fractal_style_validate_markup` on every created or changed markup
   surface before claiming completion.
6. If validation fails, replace invalid styling with verified classes and
   validate again.
7. If the registry cannot express a requirement, stop and report a coverage
   gap. Do not add CSS, Sass, a style attribute, a style block, a custom
   property, an arbitrary-value class, or a new class name.

## Hard boundaries

- No `<style>` blocks or component-scoped styles.
- No `style="..."` or style bindings.
- No new `.class` definitions in CSS or Sass.
- No new Sass variables or CSS custom properties.
- No arbitrary values encoded into class names.
- No dynamic class expression unless every possible emitted class is verified.
- Contextual modifiers such as `primary`, `ghost`, `active`, `xcenter`, and
  `open` require a compatible canonical base. Read each entry's `requires`.
- Do not silently retain unknown classes copied from examples or legacy code.

Read `references/composition-rules.md` only when resolving a coverage gap or
choosing among several valid compositions.
