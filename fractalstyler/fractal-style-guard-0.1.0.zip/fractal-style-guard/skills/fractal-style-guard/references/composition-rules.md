# Composition rules

Prefer semantic recipes, then combine the smallest verified class set that
covers structure, spacing, surface, type, and interaction.

- Structure: start with `box`, `row`, `grid`, a named grid, or a shell class.
- Alignment modifiers require a compatible container; never use them alone.
- Spacing: use named token steps before pixel literals.
- Responsive changes: use only emitted `-mob` and `-desk` variants.
- Surface: choose role classes such as `surface`, `raised`, or `panel`; do not
  infer a semantic role from a raw color.
- Interaction: start from canonical controls such as `button`, `input`,
  `select`, or `pill`, then apply only compatible modifiers.
- Accessibility behavior remains explicit in markup and script. Styling
  classes do not replace roles, labels, focus management, or ARIA state.

When no verified combination covers a requirement, return a structured gap:

```text
Fractal coverage gap
Requirement: <uncovered visual behavior>
Closest verified composition: <classes or recipe>
Missing capability: <precise property or state>
Action needed: design-system owner decision
```
