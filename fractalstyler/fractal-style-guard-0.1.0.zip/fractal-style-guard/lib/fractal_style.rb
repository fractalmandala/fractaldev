# frozen_string_literal: true

require 'json'

module FractalStyle
	class Registry
		CLASS_ATTR_RE = /\bclass(?:Name)?\s*=\s*["']([^"']*)["']/m.freeze
		SVELTE_DIRECTIVE_RE = /\bclass:([a-zA-Z_-][\w-]*)/.freeze
		STYLE_BLOCK_RE = /<style(?:\s[^>]*)?>/i.freeze
		STYLE_ATTR_RE = /\bstyle\s*=|\bstyle:/i.freeze
		DYNAMIC_CLASS_RE = /\bclass(?:Name)?\s*=\s*\{|\bclass(?:Name)?\s*=\s*["'][^"']*\$\{/m.freeze
		CSS_CLASS_DEF_RE = /(?:^|[}\s])\.([a-zA-Z_-][\w-]*)\s*(?:[,>{]|$)/.freeze
		STYLE_CONTENT_RE = /<style(?:\s[^>]*)?>(.*?)<\/style>/mi.freeze
		CUSTOM_PROPERTY_RE = /--[a-zA-Z_-][\w-]*\s*:/.freeze
		SASS_VARIABLE_RE = /^\s*\$[a-zA-Z_-][\w-]*\s*:/.freeze

		attr_reader :policy

		def initialize(root)
			@root = root
			@document = JSON.parse(File.read(File.join(root, 'data', 'registry.json')))
			@classes = @document.fetch('classes')
			@index = @classes.to_h { |entry| [entry.fetch('name'), entry] }
			@recipes = JSON.parse(File.read(File.join(root, 'data', 'recipes.json'))).fetch('recipes')
			@policy = JSON.parse(File.read(File.join(root, 'config', 'policy.json')))
		end

		def rules
			{
				'schemaVersion' => policy.fetch('schemaVersion'),
				'mode' => policy.fetch('mode'),
				'requiredWorkflow' => policy.fetch('requiredWorkflow'),
				'forbidden' => policy.fetch('forbidden'),
				'onCoverageGap' => policy.fetch('onCoverageGap'),
				'classCount' => @classes.length,
				'recipeCount' => @recipes.length
			}
		end

		def get_class(name)
			@index[name.to_s.sub(/^\./, '')]
		end

		def search_classes(query: nil, family: nil, kind: nil, layer: nil, limit: 30, offset: 0)
			words = query.to_s.downcase.split(/\s+/).reject(&:empty?)
			matches = @classes.select do |entry|
				haystack = [entry['name'], entry['intent'], entry['family'], entry['layer']].join(' ').downcase
				words.all? { |word| haystack.include?(word) } &&
					(family.nil? || entry['family'] == family) &&
					(kind.nil? || entry['kind'] == kind) &&
					(layer.nil? || entry['layer'] == layer)
			end
			page(matches, limit, offset)
		end

		def find_recipes(query:, limit: 10)
			words = query.to_s.downcase.split(/\s+/).reject(&:empty?)
			scored = @recipes.map do |recipe|
				haystack = ([recipe['name']] + recipe['intents'] + [recipe['notes']]).join(' ').downcase
				score = words.count { |word| haystack.include?(word) }
				[score, recipe]
			end
			scored.select { |score, _| score.positive? }.sort_by { |score, recipe| [-score, recipe['name']] }.first(clamp(limit, 1, 25)).map(&:last)
		end

		def validate_markup(code)
			code = code.to_s
			classes = code.scan(CLASS_ATTR_RE).flatten.flat_map { |value| value.split(/\s+/) }
			classes += code.scan(SVELTE_DIRECTIVE_RE).flatten
			classes = classes.reject(&:empty?).uniq.sort
			unknown = classes.reject { |name| @index.key?(name) }
			violations = []
			violations << violation('style-block', 'Remove the style block and compose with canonical classes.') if code.match?(STYLE_BLOCK_RE)
			violations << violation('style-attribute', 'Remove inline or bound styles and compose with canonical classes.') if code.match?(STYLE_ATTR_RE)
			violations << violation('unverified-dynamic-class', 'Enumerate and validate every possible class instead of emitting an open dynamic expression.') if code.match?(DYNAMIC_CLASS_RE)
			violations << violation('new-css-custom-property', 'Do not define custom properties outside the canonical token source.') if code.match?(CUSTOM_PROPERTY_RE)
			violations << violation('new-sass-variable', 'Do not define Sass variables in guarded UI output.') if code.match?(SASS_VARIABLE_RE)
			unknown.each { |name| violations << violation('unknown-class', ".#{name} is not in the canonical registry.", name) }

			css_sources = code.scan(STYLE_CONTENT_RE).flatten
			css_sources << code if css_sources.empty? && code.lstrip.start_with?('.', '$')
			css_sources.flat_map { |source| source.scan(CSS_CLASS_DEF_RE).flatten }.uniq.each do |name|
				violations << violation('new-css-selector', ".#{name} is a selector definition; guarded output may only reference classes.", name)
			end

			{
				'valid' => violations.empty?, 'classes' => classes, 'unknownClasses' => unknown,
				'violations' => violations, 'nextAction' => violations.empty? ? 'complete' : 'replace-or-report-gap'
			}
		end

		def validate_recipes
			@recipes.map do |recipe|
				result = validate_markup(recipe.fetch('markup'))
				{ 'id' => recipe.fetch('id'), 'valid' => result['valid'], 'violations' => result['violations'] }
			end
		end

		private

		def page(items, limit, offset)
			limit = clamp(limit, 1, 100)
			offset = [offset.to_i, 0].max
			page_items = items.slice(offset, limit) || []
			{
				'totalCount' => items.length, 'count' => page_items.length, 'offset' => offset,
				'items' => page_items, 'hasMore' => offset + page_items.length < items.length,
				'nextOffset' => offset + page_items.length
			}
		end

		def clamp(value, minimum, maximum)
			[[value.to_i, minimum].max, maximum].min
		end

		def violation(code, message, class_name = nil)
			result = { 'code' => code, 'message' => message }
			result['className'] = class_name if class_name
			result
		end
	end
end
