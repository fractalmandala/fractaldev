#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require_relative '../lib/fractal_style'

ROOT = File.expand_path('..', __dir__)
REGISTRY = FractalStyle::Registry.new(ROOT)

TOOLS = [
	{
		'name' => 'fractal_style_get_rules',
		'description' => 'Get the closed-world styling policy. Call before any Fractal UI styling task.',
		'inputSchema' => { 'type' => 'object', 'properties' => {}, 'additionalProperties' => false },
		'annotations' => { 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false }
	},
	{
		'name' => 'fractal_style_search_classes',
		'description' => 'Search canonical classes by name, intent, family, kind, or layer. Results are paginated.',
		'inputSchema' => {
			'type' => 'object',
			'properties' => {
				'query' => { 'type' => 'string' }, 'family' => { 'type' => 'string' },
				'kind' => { 'type' => 'string' }, 'layer' => { 'type' => 'string' },
				'limit' => { 'type' => 'integer', 'minimum' => 1, 'maximum' => 100, 'default' => 30 },
				'offset' => { 'type' => 'integer', 'minimum' => 0, 'default' => 0 }
			},
			'additionalProperties' => false
		},
		'annotations' => { 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false }
	},
	{
		'name' => 'fractal_style_get_class',
		'description' => 'Get one canonical class by exact name, including intent, source, tokens, and composition requirements.',
		'inputSchema' => {
			'type' => 'object', 'required' => ['name'],
			'properties' => { 'name' => { 'type' => 'string', 'description' => 'Class name with or without the leading dot.' } },
			'additionalProperties' => false
		},
		'annotations' => { 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false }
	},
	{
		'name' => 'fractal_style_find_recipes',
		'description' => 'Find registry-validated UI recipes by user intent. Prefer recipes before assembling classes individually.',
		'inputSchema' => {
			'type' => 'object', 'required' => ['query'],
			'properties' => { 'query' => { 'type' => 'string' }, 'limit' => { 'type' => 'integer', 'minimum' => 1, 'maximum' => 25, 'default' => 10 } },
			'additionalProperties' => false
		},
		'annotations' => { 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false }
	},
	{
		'name' => 'fractal_style_validate_markup',
		'description' => 'Validate markup against the closed registry and reject unknown classes, style blocks, inline styles, custom properties, Sass variables, and CSS class definitions.',
		'inputSchema' => {
			'type' => 'object', 'required' => ['code'],
			'properties' => { 'code' => { 'type' => 'string', 'description' => 'Complete changed markup or component source.' } },
			'additionalProperties' => false
		},
		'annotations' => { 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false }
	}
].freeze

def call_tool(name, args)
	case name
	when 'fractal_style_get_rules' then REGISTRY.rules
	when 'fractal_style_search_classes'
		REGISTRY.search_classes(query: args['query'], family: args['family'], kind: args['kind'], layer: args['layer'], limit: args.fetch('limit', 30), offset: args.fetch('offset', 0))
	when 'fractal_style_get_class'
		entry = REGISTRY.get_class(args.fetch('name'))
		raise ArgumentError, "Unknown class #{args['name'].inspect}. Search the registry or report a coverage gap." unless entry
		entry
	when 'fractal_style_find_recipes' then REGISTRY.find_recipes(query: args.fetch('query'), limit: args.fetch('limit', 10))
	when 'fractal_style_validate_markup' then REGISTRY.validate_markup(args.fetch('code'))
	else raise ArgumentError, "Unknown tool #{name.inspect}"
	end
end

def tool_result(data, error: false)
	{
		'content' => [{ 'type' => 'text', 'text' => JSON.pretty_generate(data) }],
		'structuredContent' => data,
		'isError' => error
	}
end

def handle(request)
	method = request['method']
	params = request['params'] || {}
	result = case method
	when 'initialize'
		{
			'protocolVersion' => params['protocolVersion'] || '2025-03-26',
			'capabilities' => { 'tools' => {}, 'resources' => {}, 'prompts' => {} },
			'serverInfo' => { 'name' => 'fractal_style_mcp', 'version' => '0.1.0' }
		}
	when 'tools/list' then { 'tools' => TOOLS }
	when 'tools/call'
		begin
			tool_result(call_tool(params.fetch('name'), params['arguments'] || {}))
		rescue KeyError, ArgumentError => error
			tool_result({ 'error' => error.message, 'nextAction' => 'correct-input-or-report-gap' }, error: true)
		end
	when 'resources/list'
		{
			'resources' => [
				{ 'uri' => 'fractal://rules', 'name' => 'Closed-world styling rules', 'mimeType' => 'application/json' },
				{ 'uri' => 'fractal://registry', 'name' => 'Canonical class registry', 'mimeType' => 'application/json' },
				{ 'uri' => 'fractal://recipes', 'name' => 'Validated composition recipes', 'mimeType' => 'application/json' }
			]
		}
	when 'resources/read'
		path = { 'fractal://rules' => 'config/policy.json', 'fractal://registry' => 'data/registry.json', 'fractal://recipes' => 'data/recipes.json' }[params['uri']]
		raise ArgumentError, "Unknown resource #{params['uri'].inspect}" unless path
		{ 'contents' => [{ 'uri' => params['uri'], 'mimeType' => 'application/json', 'text' => File.read(File.join(ROOT, path)) }] }
	when 'prompts/list'
		{
			'prompts' => [
				{ 'name' => 'design-with-fractals', 'description' => 'Compose a UI under the closed Fractal styling contract.', 'arguments' => [{ 'name' => 'request', 'required' => true }] },
				{ 'name' => 'audit-fractal-markup', 'description' => 'Audit markup for styling contract violations.', 'arguments' => [{ 'name' => 'code', 'required' => true }] }
			]
		}
	when 'prompts/get'
		text = if params['name'] == 'audit-fractal-markup'
			"Validate this complete markup with fractal_style_validate_markup and report every violation. Do not fix by adding CSS.\n\n#{params.dig('arguments', 'code')}"
		else
			"Use the mandatory discover-compose-validate workflow. Use only canonical Fractal classes; report any coverage gap.\n\n#{params.dig('arguments', 'request')}"
		end
		{ 'description' => 'Fractal closed-world workflow', 'messages' => [{ 'role' => 'user', 'content' => { 'type' => 'text', 'text' => text } }] }
	else
		return nil if method.to_s.start_with?('notifications/')
		raise ArgumentError, "Unsupported method #{method.inspect}"
	end
	{ 'jsonrpc' => '2.0', 'id' => request['id'], 'result' => result }
rescue StandardError => error
	{ 'jsonrpc' => '2.0', 'id' => request['id'], 'error' => { 'code' => -32602, 'message' => error.message } }
end

if $PROGRAM_NAME == __FILE__
	STDOUT.sync = true
	ARGF.each_line do |line|
		request = JSON.parse(line)
		response = handle(request)
		puts JSON.generate(response) if response && request.key?('id')
	rescue JSON::ParserError => error
		puts JSON.generate({ 'jsonrpc' => '2.0', 'id' => nil, 'error' => { 'code' => -32700, 'message' => error.message } })
	end
end
